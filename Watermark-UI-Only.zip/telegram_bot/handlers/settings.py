from __future__ import annotations

import re
from pyrogram import filters
from pyrogram.enums import ParseMode
from pyrogram.types import CallbackQuery, Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.config import CHANNEL_URL
from telegram_bot.constants import COLORS
from telegram_bot.db import get_settings, reset_settings, update_settings
from telegram_bot.handlers.start import HELP_TEXT
from telegram_bot.utils.membership import require_channel_membership
from telegram_bot.utils.formatting import config_overview_card, settings_summary, vip_feature_card
from telegram_bot.utils.keyboards import (
    animation_keyboard,
    cancel_keyboard,
    color_keyboard,
    font_keyboard,
    main_menu_keyboard,
    media_subconfig_keyboard,
    opacity_keyboard,
    overview_keyboard,
    position_keyboard,
    size_keyboard,
    vip_keyboard,
)

CALLBACK_PATTERN = re.compile(
    r"^(m|close|reset|help|nav:(start)|sub:(video|image|pdf|global)|mode:(text|image)|pos:(menu|[a-z_]+)|anim:(menu|[a-z_]+)|"
    r"font:(menu|[a-z_]+)|color:(menu|custom|[a-z]+)|size:(menu|custom|\d+)|"
    r"opacity:(menu|custom|\d+)|text:ask|logo:ask)$"
)

async def _edit_callback_message(message: Message, text: str, reply_markup=None) -> None:
    """Edit message safely using HTML parse mode for card blockquotes."""
    try:
        if message.photo or message.video or message.animation or message.document:
            await message.edit_caption(text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
        else:
            await message.edit_text(text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    except Exception:
        pass

async def _answer_callback(cq: CallbackQuery, text: str | None = None, **kwargs) -> None:
    if text is None:
        await cq.answer(**kwargs)
    else:
        await cq.answer(text, **kwargs)

@app.on_message(filters.command("settings") & filters.private)
async def settings_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    settings = await get_settings(message.from_user.id)
    await message.reply_text(
        settings_summary(settings),
        reply_markup=main_menu_keyboard(settings),
        parse_mode=ParseMode.HTML
    )

@app.on_message(filters.command(["mysettings", "overview"]) & filters.private)
async def mysettings_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    settings = await get_settings(message.from_user.id)
    await message.reply_text(
        config_overview_card(settings),
        reply_markup=overview_keyboard(),
        parse_mode=ParseMode.HTML
    )

@app.on_message(filters.command(["batch", "vip"]) & filters.private)
async def batch_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    admin_link = CHANNEL_URL or "https://t.me/telegram"
    await message.reply_text(
        vip_feature_card(),
        reply_markup=vip_keyboard(admin_link),
        parse_mode=ParseMode.HTML
    )

@app.on_callback_query(filters.regex(CALLBACK_PATTERN))
async def settings_callback(client, cq: CallbackQuery):
    user_id = cq.from_user.id
    data = cq.data

    if cq.message is not None and not await require_channel_membership(
        client, cq.message, user_id=user_id
    ):
        await _answer_callback(cq, "Please join the channel before using the bot.", show_alert=True)
        return

    if data == "nav:start":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await _answer_callback(cq)
        return

    if data == "m":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("sub:"):
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=media_subconfig_keyboard(settings))
        await _answer_callback(cq)
        return

    if data == "help":
        await _answer_callback(cq)
        await _edit_callback_message(cq.message, HELP_TEXT)
        return

    if data == "close":
        await _edit_callback_message(cq.message,
            "✅ <b>Settings saved.</b> Send me any photo, video, or GIF to watermark it!"
        )
        await _answer_callback(cq, "Saved")
        return

    if data == "reset":
        settings = await reset_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await _answer_callback(cq, "Reset to defaults")
        return

    if data.startswith("mode:"):
        mode = data.split(":", 1)[1]
        settings = await update_settings(user_id, mode=mode)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=media_subconfig_keyboard(settings))
        await _answer_callback(cq, f"Mode set to {mode}")
        return

    if data == "pos:menu":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=position_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("pos:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, position=value)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=position_keyboard(settings))
        await _answer_callback(cq, "Position updated")
        return

    if data == "anim:menu":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=animation_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("anim:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, animation=value)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=animation_keyboard(settings))
        await _answer_callback(cq, "Animation updated")
        return

    if data == "font:menu":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=font_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("font:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, font=value)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=font_keyboard(settings))
        await _answer_callback(cq, "Font updated")
        return

    if data == "color:menu":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=color_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("color:"):
        value = data.split(":", 1)[1]
        if value == "custom":
            PENDING_INPUT[user_id] = "color"
            await cq.message.reply_text(
                "🎨 Send a hex color code (e.g. <code>#FFFFFF</code> or <code>#FF5500</code>):",
                reply_markup=cancel_keyboard(),
                parse_mode=ParseMode.HTML
            )
            await _answer_callback(cq)
            return
        hexval = COLORS.get(value, "#FFFFFF")
        settings = await update_settings(user_id, color=hexval)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=color_keyboard(settings))
        await _answer_callback(cq, f"Color: {value}")
        return

    if data == "size:menu":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=size_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("size:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, size=int(value))
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=size_keyboard(settings))
        await _answer_callback(cq, f"Size: {value}%")
        return

    if data == "opacity:menu":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=opacity_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("opacity:"):
        value = data.split(":", 1)[1]
        settings = await update_settings(user_id, opacity=int(value))
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=opacity_keyboard(settings))
        await _answer_callback(cq, f"Opacity: {value}%")
        return

    if data == "text:ask":
        PENDING_INPUT[user_id] = "text"
        await cq.message.reply_text(
            "✏️ Send the watermark text you want to use (up to 40 characters):",
            reply_markup=cancel_keyboard(),
            parse_mode=ParseMode.HTML
        )
        await _answer_callback(cq)
        return

    if data == "logo:ask":
        PENDING_INPUT[user_id] = "logo"
        await cq.message.reply_text(
            "🖼️ Please send the image you want to use as your watermark logo.",
            reply_markup=cancel_keyboard(),
            parse_mode=ParseMode.HTML
        )
        await _answer_callback(cq)
        return
