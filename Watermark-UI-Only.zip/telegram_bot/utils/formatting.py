"""UI formatters implementing the NOVA Studio / reference visual design language."""
from __future__ import annotations

from typing import Any
from telegram_bot.constants import ANIMATIONS, FONTS, POSITIONS

_SERIF_BOLD_OFFSET_UPPER = 0x1D400 - ord('A')  # 𝐀
_SERIF_BOLD_OFFSET_LOWER = 0x1D41A - ord('a')  # 𝐚

def serif_bold(text: str) -> str:
    """Transform standard letters into Unicode Mathematical Bold Serif."""
    out = []
    for char in text:
        code = ord(char)
        if ord('A') <= code <= ord('Z'):
            out.append(chr(code + _SERIF_BOLD_OFFSET_UPPER))
        elif ord('a') <= code <= ord('z'):
            out.append(chr(code + _SERIF_BOLD_OFFSET_LOWER))
        else:
            out.append(char)
    return "".join(out)

def format_card(header: str, body: str, *, expandable: bool = True) -> str:
    """Expandable inset panel card matching Telegram native blockquote container."""
    tag = '<blockquote expandable>' if expandable else '<blockquote>'
    return f"{tag}<b>{header}</b>\n\n{body}</blockquote>"

def settings_summary(settings: dict[str, Any]) -> str:
    """Renders the Settings Hub message in the exact style of the reference."""
    title = f"🎨 <b>{serif_bold('Watermark Settings Hub')}</b>"
    body = (
        "Select a media category below to configure watermarks for your files.\n"
        "Each media category maintains independent persistent settings."
    )
    card = format_card("⚙️ Pipeline Profiles", body, expandable=True)
    return f"{title}\n\n{card}"

def vip_feature_card() -> str:
    """VIP / Channel Batch Watermarking view."""
    title = f"👑 <b>{serif_bold('VIP Exclusive Feature — Channel Batch')}</b>"
    body = (
        "⚡ <b>Channel Batch Watermarking</b> is an automated tool "
        "reserved exclusively for VIP & Ultra Plan users."
    )
    card = format_card("⚡ Accelerated Feature", body, expandable=True)
    return f"{title}\n\n{card}"

def config_overview_card(settings: dict[str, Any]) -> str:
    """Tabular configuration overview matching the /mysettings reference screen."""
    title = f"📊 <b>{serif_bold('My Watermark Configuration')}</b>"
    
    mode = settings.get("mode", "text")
    txt = (settings.get("text") or "@YourBrand")[:16]
    font_name = FONTS.get(settings.get("font", "poppins_bold"), ("Poppins", ""))[0][:7]
    
    lines = [
        f"{'Media':<7} {'Status':<6} {'Text':<17} {'Font':<7}",
        "─" * 40,
        f"{'📹 Video':<7} {'🟢 ON':<6} {txt:<17} {font_name:<7}",
        f"{'🖼️ Image':<7} {'🟢 ON':<6} {txt:<17} {font_name:<7}",
        f"{'📄 PDF':<7}   {'🟢 ON':<6} {txt:<17} {font_name:<7}",
    ]
    table = "<pre>\n" + "\n".join(lines) + "\n</pre>"
    
    notice = (
        "Video, Image, and PDF maintain isolated settings. "
        "To modify any setting, tap the buttons below."
    )
    card = format_card("📌 Configuration Notice", notice, expandable=True)
    return f"{title}\n\n{table}\n\n{card}"
