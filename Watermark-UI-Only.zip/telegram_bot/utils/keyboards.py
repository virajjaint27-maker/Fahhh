"""Inline keyboard builders matching the reference layout."""
from __future__ import annotations

from typing import Any
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from telegram_bot.constants import ANIMATIONS, COLORS, FONTS, OPACITY_PRESETS, POSITIONS, SIZE_PRESETS

def _mark(label: str, selected: bool) -> str:
    return f"✅ {label}" if selected else label

def _button(label: str, callback_data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(label, callback_data=callback_data)

def main_menu_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    """Exact 2x2 Settings Hub grid + Full-width bottom navigation."""
    return InlineKeyboardMarkup([
        [
            _button("📹 Video Watermark", "sub:video"),
            _button("🖼️ Image Watermark", "sub:image"),
        ],
        [
            _button("📄 PDF Watermark", "sub:pdf"),
            _button("🌐 Global Defaults", "sub:global"),
        ],
        [
            _button("🏠 Back to Main Menu", "nav:start"),
        ]
    ])

def overview_keyboard() -> InlineKeyboardMarkup:
    """Exact 3-column media selector + Full-width bottom navigation."""
    return InlineKeyboardMarkup([
        [
            _button("📹 Video", "sub:video"),
            _button("🖼️ Image", "sub:image"),
            _button("📄 PDF", "sub:pdf"),
        ],
        [
            _button("🏠 Back to Start", "nav:start"),
        ]
    ])

def vip_keyboard(admin_url: str = "https://t.me/telegram") -> InlineKeyboardMarkup:
    """VIP CTA button + Full-width bottom navigation."""
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🧑‍💻 Contact Admin for VIP Plan ↗", url=admin_url),
        ],
        [
            _button("🏠 Back to Start", "nav:start"),
        ]
    ])

def media_subconfig_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    """Detailed options for adjusting watermark parameters."""
    mode = settings.get("mode", "text")
    rows = [
        [
            _button(_mark("🅰️ Text Mode", mode == "text"), "mode:text"),
            _button(_mark("🖼️ Logo Mode", mode == "image"), "mode:image"),
        ],
    ]
    if mode == "text":
        rows.append([_button(f"✏️ Text: {settings.get('text', '')[:16]}", "text:ask")])
        rows.append([
            _button("🔤 Font", "font:menu"),
            _button("🎨 Color", "color:menu"),
        ])
    else:
        rows.append([_button("🖼️ Upload Logo Image", "logo:ask")])

    rows.append([
        _button("📏 Size", "size:menu"),
        _button("💧 Opacity", "opacity:menu"),
    ])
    rows.append([
        _button("📍 Position", "pos:menu"),
        _button("🎬 Animation", "anim:menu"),
    ])
    rows.append([
        _button("🏠 Back to Settings Hub", "m"),
    ])
    return InlineKeyboardMarkup(rows)

def back_row(target: str = "sub:video") -> list[InlineKeyboardButton]:
    return [_button("🔙 Back", target)]

def position_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("position")
    rows = []
    items = list(POSITIONS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, label in items[i : i + 2]:
            row.append(_button(_mark(label, current == key), f"pos:{key}"))
        rows.append(row)
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)

def animation_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("animation")
    rows = []
    for key, label in ANIMATIONS.items():
        rows.append([_button(_mark(label, current == key), f"anim:{key}")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)

def font_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("font")
    rows = []
    items = list(FONTS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, (label, _file) in items[i : i + 2]:
            row.append(_button(_mark(label, current == key), f"font:{key}"))
        rows.append(row)
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)

def color_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = (settings.get("color") or "").upper()
    rows = []
    items = list(COLORS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, hexval in items[i : i + 2]:
            selected = current == hexval.upper()
            row.append(_button(_mark(f"● {key.title()}", selected), f"color:{key}"))
        rows.append(row)
    rows.append([_button("🎨 Custom HEX", "color:custom")])
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)

def size_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("size")
    rows = [[]]
    for preset in SIZE_PRESETS:
        rows[0].append(_button(_mark(f"{preset}%", current == preset), f"size:{preset}"))
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)

def opacity_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    current = settings.get("opacity")
    rows = [[]]
    for preset in OPACITY_PRESETS:
        rows[0].append(_button(_mark(f"{preset}%", current == preset), f"opacity:{preset}"))
    rows.append(back_row())
    return InlineKeyboardMarkup(rows)

def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="m")]])
