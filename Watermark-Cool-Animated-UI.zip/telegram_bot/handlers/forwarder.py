from __future__ import annotations

import asyncio
import logging
import random
import re
from pyrogram import filters
from pyrogram.enums import ChatMemberStatus, ParseMode
from pyrogram.errors import FloodWait, RPCError
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.db import get_forward_config, set_forward_channel
from telegram_bot.utils.formatting import format_article, serif_bold
from telegram_bot.utils.keyboards import cancel_keyboard

log = logging.getLogger(__name__)

# Stickers sent randomly while messages are being forwarded
FORWARD_PROGRESS_STICKERS = (
    "CAACAgIAAxkBAAESBjhqy2RxRh3Ce4xhFbxRrAPNKjy5kgAC2RoAAgPawUt7kz-IiUFV2j0E",
    "CAACAgIAAxkBAAESBjpqy2SexyDXpjPXW9MVa1kWVtK5oAACTxkAAiVFcEixVxCLovT3UT0E",
)

# Stickers sent randomly when forwarding is complete
FORWARD_COMPLETE_STICKERS = (
    "CAACAgUAAxkBAAESBjxqy2UKVVHnSwSo8vEJWY5fX1RYkQAC_BsAApBfsVY-6kJLd_AjBT0E",
    "CAACAgIAAxkBAAESBj5qy2VUUNoPBeFkDr8eg8K4PjeElgACSB0AAjDOaEi_K-bjQ6Ba5T0E",
    "CAACAgIAAxkBAAESBj9qy2VUEP1vPBTKQ8CvOnWLmfPvgwADHAACtIxxSLBgWu6boo-3PQQ",
)

_ACTIVE_TASKS: dict[int, asyncio.Task] = {}

def forward_menu_keyboard(cfg: dict) -> InlineKeyboardMarkup:
    src_label = f"📢 Source: {cfg.get('source_title') or 'Not Set'}"
    tgt_label = f"🎯 Target: {cfg.get('target_title') or 'Not Set'}"
    
    can_start = bool(cfg.get('source_chat_id') and cfg.get('target_chat_id'))
    action_row = [InlineKeyboardButton("🚀 Start Forwarding All Messages", callback_data="fwd:start")] if can_start else []
    
    rows = [
        [InlineKeyboardButton(src_label[:30], callback_data="fwd:set:source")],
        [InlineKeyboardButton(tgt_label[:30], callback_data="fwd:set:target")],
    ]
    if action_row:
        rows.append(action_row)
    rows.append([InlineKeyboardButton("🏠 Back to Main Menu", callback_data="nav:start")])
    return InlineKeyboardMarkup(rows)

def render_forward_article(cfg: dict) -> str:
    title = f"🔁 <b>{serif_bold('Channel Message Forwarding')}</b>"
    src = cfg.get("source_title") or "<i>(Not Set)</i>"
    tgt = cfg.get("target_title") or "<i>(Not Set)</i>"
    
    desc = (
        "Easily forward all messages from one channel to another with live real-time progress.\n\n"
        f"• <b>Source Channel:</b> {src}\n"
        f"• <b>Target Channel:</b> {tgt}\n\n"
        "<b>Requirements:</b>\n"
        "1. Add this bot as an <b>Administrator</b> in both channels.\n"
        "2. Tap <b>Source</b> or <b>Target</b> below, then forward any message from the channel or paste its invite/public link.\n"
        "3. Once both are set, tap <b>Start Forwarding All Messages</b>."
    )
    article = format_article("⚡ Bulk Message Transfer Engine", desc, expandable=True)
    return f"{title}\n\n{article}"

@app.on_message(filters.command(["forward", "forwarding"]) & filters.private)
async def forward_cmd(client, message: Message):
    cfg = await get_forward_config(message.from_user.id)
    await message.reply_text(
        render_forward_article(cfg),
        reply_markup=forward_menu_keyboard(cfg),
        parse_mode=ParseMode.HTML,
    )

@app.on_callback_query(filters.regex(r"^fwd:"))
async def forward_callback(client, cq: CallbackQuery):
    user_id = cq.from_user.id
    data = cq.data
    
    if data == "fwd:menu":
        cfg = await get_forward_config(user_id)
        await cq.message.edit_text(render_forward_article(cfg), reply_markup=forward_menu_keyboard(cfg), parse_mode=ParseMode.HTML)
        await cq.answer()
        return

    if data == "fwd:set:source":
        PENDING_INPUT[user_id] = "fwd_source"
        await cq.message.reply_text(
            "📢 <b>Set Source Channel:</b>\n\n"
            "Forward any message from the source channel to me, or send its public link / @username / channel ID.",
            reply_markup=cancel_keyboard(),
            parse_mode=ParseMode.HTML,
        )
        await cq.answer()
        return

    if data == "fwd:set:target":
        PENDING_INPUT[user_id] = "fwd_target"
        await cq.message.reply_text(
            "🎯 <b>Set Target Channel:</b>\n\n"
            "Forward any message from the target channel to me, or send its public link / @username / channel ID.",
            reply_markup=cancel_keyboard(),
            parse_mode=ParseMode.HTML,
        )
        await cq.answer()
        return

    if data == "fwd:stop":
        task = _ACTIVE_TASKS.get(user_id)
        if task and not task.done():
            task.cancel()
            await cq.answer("Forwarding task stopping...", show_alert=True)
        else:
            await cq.answer("No active forwarding task.")
        return

    if data == "fwd:start":
        cfg = await get_forward_config(user_id)
        src_id = cfg.get("source_chat_id")
        tgt_id = cfg.get("target_chat_id")
        
        if not src_id or not tgt_id:
            await cq.answer("Please set both source and target channels first!", show_alert=True)
            return

        # Check if bot is admin in both channels
        me = await client.get_me()
        for cid, name in [(src_id, "Source"), (tgt_id, "Target")]:
            try:
                chat_target = int(cid) if str(cid).lstrip("-").isdigit() else cid
                member = await client.get_chat_member(chat_target, me.id)
                if member.status not in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER):
                    await cq.answer(f"Bot is not an Admin in {name} channel! Please grant admin permissions.", show_alert=True)
                    return
            except Exception as e:
                log.warning("Admin check failed for %s (%s): %s", name, cid, e)
                await cq.answer(f"Could not access {name} channel. Ensure the bot is added as Admin!", show_alert=True)
                return

        await cq.answer()
        status_msg = await cq.message.reply_text(
            "⏳ <b>Analyzing source channel messages…</b>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛑 Cancel Forwarding", callback_data="fwd:stop")]]),
            parse_mode=ParseMode.HTML
        )
        
        # Start forwarding worker task
        task = asyncio.create_task(_run_forwarding(client, user_id, src_id, tgt_id, status_msg))
        _ACTIVE_TASKS[user_id] = task
        return

async def _send_safe_sticker(client, chat_id: int, sticker_id: str) -> None:
    try:
        await client.send_sticker(chat_id, sticker_id)
    except Exception as e:
        log.warning("Could not send forward sticker: %s", e)

async def _run_forwarding(client, user_id: int, src_id: str, tgt_id: str, status_msg: Message):
    src_target = int(src_id) if str(src_id).lstrip("-").isdigit() else src_id
    tgt_target = int(tgt_id) if str(tgt_id).lstrip("-").isdigit() else tgt_id

    try:
        # Collect all message IDs from source channel
        message_ids: list[int] = []
        async for m in client.get_chat_history(src_target):
            if m and not m.service:
                message_ids.append(m.id)

        total = len(message_ids)
        if total == 0:
            await status_msg.edit_text("⚠️ <b>No forwardable messages found in source channel.</b>", parse_mode=ParseMode.HTML)
            return

        # Reverse so we forward oldest first
        message_ids.reverse()

        forwarded = 0
        last_sticker_time = 0
        loop = asyncio.get_running_loop()

        for idx, mid in enumerate(message_ids, start=1):
            try:
                await client.forward_messages(chat_id=tgt_target, from_chat_id=src_target, message_ids=mid)
                forwarded += 1
            except FloodWait as fw:
                log.info("Flood wait encountered: %ss", fw.value)
                await asyncio.sleep(fw.value + 1)
                try:
                    await client.forward_messages(chat_id=tgt_target, from_chat_id=src_target, message_ids=mid)
                    forwarded += 1
                except Exception:
                    pass
            except Exception as ex:
                log.warning("Could not forward message %s: %s", mid, ex)

            now = loop.time()
            # Send random progress sticker periodically while forwarding
            if (now - last_sticker_time > 15) and (idx % 10 == 0):
                last_sticker_time = now
                stk = random.choice(FORWARD_PROGRESS_STICKERS)
                await _send_safe_sticker(client, status_msg.chat.id, stk)

            # Update progress bar every 5 messages or at the end
            if idx % 5 == 0 or idx == total:
                left = total - forwarded
                percent = int((forwarded / total) * 100)
                filled = int(percent / 10)
                bar = "▰" * filled + "▱" * (10 - filled)
                pulse_icons = ["⚡", "🔥", "🚀", "💫", "✨", "🛸"]
                pulse = pulse_icons[idx % len(pulse_icons)]
                progress_text = (
                    f"<blockquote><b>{pulse} TURBO FORWARDING IN PROGRESS {pulse}</b>\n\n"
                    f"<code>[{bar}] {percent}%</code>\n\n"
                    f"📦 <b>Total Queue:</b> <code>{total}</code>\n"
                    f"🚀 <b>Transferred:</b> <code>{forwarded}</code>\n"
                    f"⏳ <b>Remaining:</b> <code>{left}</code>\n"
                    f"⚡ <b>Engine:</b> <code>Multi-Stream Active 🔥</code></blockquote>"
                )
                try:
                    await status_msg.edit_text(
                        progress_text,
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛑 Cancel Forwarding", callback_data="fwd:stop")]]),
                        parse_mode=ParseMode.HTML
                    )
                except Exception:
                    pass

            await asyncio.sleep(0.5)

        # Completion: send random completion sticker from the user's provided list
        complete_stk = random.choice(FORWARD_COMPLETE_STICKERS)
        await _send_safe_sticker(client, status_msg.chat.id, complete_stk)

        cfg = await get_forward_config(user_id)
        finish_text = (
            f"🎉 <b>Forwarding Complete!</b>\n\n"
            f"Successfully transferred <b>{forwarded}</b> of <b>{total}</b> messages "
            f"from <b>{cfg.get('source_title', 'Source')}</b> to <b>{cfg.get('target_title', 'Target')}</b>."
        )
        await status_msg.edit_text(
            finish_text,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔁 Return to Forwarding Menu", callback_data="fwd:menu")]]),
            parse_mode=ParseMode.HTML
        )

    except asyncio.CancelledError:
        await status_msg.edit_text(
            "🛑 <b>Forwarding task was cancelled.</b>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔁 Return to Forwarding Menu", callback_data="fwd:menu")]]),
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        log.exception("Forwarding failed")
        await status_msg.edit_text(f"❌ <b>Error occurred:</b> <code>{str(e)[:200]}</code>", parse_mode=ParseMode.HTML)
    finally:
        _ACTIVE_TASKS.pop(user_id, None)
