"""Local SQLite persistence for per-user watermark settings and bot stats.

The database is a file on the server running the bot, so no separate database
service is required. The default file path is configured in telegram_bot/config.py.
"""
from __future__ import annotations

import json
from copy import deepcopy
from typing import Any, Optional

import aiosqlite

from telegram_bot.config import DB_PATH
from telegram_bot.constants import DEFAULT_SETTINGS

_db: Optional[aiosqlite.Connection] = None

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS telegram_watermark_settings (
    user_id INTEGER PRIMARY KEY,
    settings TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS user_forward_channels (
    user_id INTEGER PRIMARY KEY,
    source_chat_id TEXT,
    source_title TEXT,
    target_chat_id TEXT,
    target_title TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS telegram_watermark_stats (
    user_id INTEGER PRIMARY KEY,
    files_processed INTEGER NOT NULL DEFAULT 0,
    bytes_processed INTEGER NOT NULL DEFAULT 0,
    last_used_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


def _connection() -> aiosqlite.Connection:
    if _db is None:
        raise RuntimeError("SQLite is not initialized; call init_db() first.")
    return _db


async def init_db() -> None:
    """Open the local SQLite file and create tables if they do not exist."""
    global _db
    if _db is not None:
        return

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    _db = await aiosqlite.connect(str(DB_PATH), timeout=30)
    _db.row_factory = aiosqlite.Row
    async with _db.execute("PRAGMA journal_mode=WAL"):
        pass
    async with _db.execute("PRAGMA busy_timeout=5000"):
        pass
    await _db.executescript(CREATE_TABLE_SQL)
    await _db.commit()


async def close_db() -> None:
    global _db
    if _db is not None:
        connection = _db
        _db = None
        await connection.close()


def _merge_defaults(stored: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(DEFAULT_SETTINGS)
    merged.update(stored or {})
    return merged


async def get_settings(user_id: int) -> dict[str, Any]:
    db = _connection()
    async with db.execute(
        "SELECT settings FROM telegram_watermark_settings WHERE user_id = ?",
        (user_id,),
    ) as cursor:
        row = await cursor.fetchone()

    if row is None:
        defaults = deepcopy(DEFAULT_SETTINGS)
        await db.execute(
            "INSERT OR IGNORE INTO telegram_watermark_settings (user_id, settings) VALUES (?, ?)",
            (user_id, json.dumps(defaults, ensure_ascii=False)),
        )
        await db.commit()
        return defaults

    raw = row["settings"]
    stored = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(stored, dict):
        stored = {}
    return _merge_defaults(stored)


async def update_settings(user_id: int, **changes: Any) -> dict[str, Any]:
    db = _connection()
    current = await get_settings(user_id)
    current.update(changes)
    await db.execute(
        """
        INSERT INTO telegram_watermark_settings (user_id, settings, updated_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT (user_id)
        DO UPDATE SET settings = excluded.settings, updated_at = CURRENT_TIMESTAMP
        """,
        (user_id, json.dumps(current, ensure_ascii=False)),
    )
    await db.commit()
    return current


async def reset_settings(user_id: int) -> dict[str, Any]:
    db = _connection()
    defaults = deepcopy(DEFAULT_SETTINGS)
    await db.execute(
        """
        INSERT INTO telegram_watermark_settings (user_id, settings, updated_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT (user_id)
        DO UPDATE SET settings = excluded.settings, updated_at = CURRENT_TIMESTAMP
        """,
        (user_id, json.dumps(defaults, ensure_ascii=False)),
    )
    await db.commit()
    return defaults


async def record_usage(user_id: int, file_size: int) -> None:
    db = _connection()
    await db.execute(
        """
        INSERT INTO telegram_watermark_stats
            (user_id, files_processed, bytes_processed, last_used_at)
        VALUES (?, 1, ?, CURRENT_TIMESTAMP)
        ON CONFLICT (user_id)
        DO UPDATE SET
            files_processed = telegram_watermark_stats.files_processed + 1,
            bytes_processed = telegram_watermark_stats.bytes_processed + excluded.bytes_processed,
            last_used_at = CURRENT_TIMESTAMP
        """,
        (user_id, file_size),
    )
    await db.commit()


async def global_stats() -> dict[str, Any]:
    db = _connection()
    async with db.execute(
        """
        SELECT
            COUNT(*) AS users,
            COALESCE(SUM(files_processed), 0) AS files_processed,
            COALESCE(SUM(bytes_processed), 0) AS bytes_processed
        FROM telegram_watermark_stats
        """
    ) as cursor:
        row = await cursor.fetchone()
    return dict(row) if row is not None else {
        "users": 0,
        "files_processed": 0,
        "bytes_processed": 0,
    }


async def get_forward_config(user_id: int) -> dict[str, Any]:
    db = _connection()
    async with db.execute(
        "SELECT source_chat_id, source_title, target_chat_id, target_title FROM user_forward_channels WHERE user_id = ?",
        (user_id,)
    ) as cur:
        row = await cur.fetchone()
        if row:
            return {
                "source_chat_id": row[0],
                "source_title": row[1],
                "target_chat_id": row[2],
                "target_title": row[3],
            }
        return {
            "source_chat_id": None,
            "source_title": None,
            "target_chat_id": None,
            "target_title": None,
        }

async def set_forward_channel(user_id: int, role: str, chat_id: str | int, title: str) -> None:
    db = _connection()
    cfg = await get_forward_config(user_id)
    if role == "source":
        cfg["source_chat_id"] = str(chat_id)
        cfg["source_title"] = title
    elif role == "target":
        cfg["target_chat_id"] = str(chat_id)
        cfg["target_title"] = title

    await db.execute("""
        INSERT INTO user_forward_channels (user_id, source_chat_id, source_title, target_chat_id, target_title)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            source_chat_id = excluded.source_chat_id,
            source_title = excluded.source_title,
            target_chat_id = excluded.target_chat_id,
            target_title = excluded.target_title,
            updated_at = CURRENT_TIMESTAMP
    """, (user_id, cfg["source_chat_id"], cfg["source_title"], cfg["target_chat_id"], cfg["target_title"]))
    await db.commit()
