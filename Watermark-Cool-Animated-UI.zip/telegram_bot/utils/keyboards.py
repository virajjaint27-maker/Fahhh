"""Inline keyboard builders with consistent grid alignment and navigation."""
from __future__ import annotations

from typing import Any
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from telegram_bot.constants import ANIMATIONS, COLORS, FONTS, OPACITY_PRESETS, POSITIONS, SIZE_PRESETS

def _mark(label: str, selected: bool) -> str:
    return f"✅ {label}" if selected else label

def _button(label: str, callback_data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(label, callback_data=callback_data)

def welcome_keyboard() -> InlineKeyboardMarkup:
    """Rich button layout under /start intro message."""
    return InlineKeyboardMarkup([
        [
            _button("🎨 Settings Hub ⚡", "m"),
            _button("📊 Active Matrix 😎", "nav:overview"),
        ],
        [
            _button("👑 VIP Ultra Plan 🔥", "nav:vip"),
            _button("📖 Help & Guides 🚀", "help"),
        ]
    ])

def main_menu_keyboard(settings: dict[str, Any]) -> InlineKeyboardMarkup:
    """Settings Hub: 2x2 Category Grid + Back to Start."""
    return InlineKeyboardMarkup([
        [
            _button("📹 Video Engine ⚡", "sub:video"),
            _button("🖼️ Image Engine 💎", "sub:image"),
        ],
        [
            _button("📄 PDF Engine 📑", "sub:pdf"),
            _button("🌐 Global Preset 🔮", "sub:global"),
        ],
        [
            _button("🏠 Return to Dashboard 🛸", "nav:start"),
        ]
    ])

def overview_keyboard() -> InlineKeyboardMarkup:
    """3-column category selector + Back button."""
    return InlineKeyboardMarkup([
        [
            _button("📹 Video", "sub:video"),
            _button("🖼️ Image", "sub:image"),
            _button("📄 PDF", "sub:pdf"),
        ],
        [
            _button("🏠 Return to Dashboard 🛸", "nav:start"),
        ]
    ])

def vip_keyboard(admin_url: str = "https://t.me/telegram") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🧑‍💻 Contact Admin for VIP Plan ↗", url=admin_url),
        ],
        [
            _button("🏠 Return to Dashboard 🛸", "nav:start"),
        ]
    ])

def media_subconfig_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    """Detailed options under each article."""
    mode = settings.get("mode", "text")
    rows = [
        [
            _button(_mark("🅰️ Text Mode", mode == "text"), f"mode:text:{category}"),
            _button(_mark("🖼️ Logo Mode", mode == "image"), f"mode:image:{category}"),
        ],
    ]
    if mode == "text":
        rows.append([_button(f"✏️ Text: {settings.get('text', '')[:16]}", f"text:ask:{category}")])
        rows.append([
            _button("🔤 Font", f"font:menu:{category}"),
            _button("🎨 Color", f"color:menu:{category}"),
        ])
    else:
        rows.append([_button("🖼️ Upload Logo Image", f"logo:ask:{category}")])

    rows.append([
        _button("📏 Size", f"size:menu:{category}"),
        _button("💧 Opacity", f"opacity:menu:{category}"),
    ])
    rows.append([
        _button("📍 Position", f"pos:menu:{category}"),
        _button("🎬 Animation", f"anim:menu:{category}"),
    ])
    rows.append([
        _button("🔙 Back to Settings Hub", "m"),
    ])
    return InlineKeyboardMarkup(rows)

def back_row(target: str = "m") -> list[InlineKeyboardButton]:
    return [_button("🔙 Back", target)]

def position_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    current = settings.get("position")
    rows = []
    items = list(POSITIONS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, label in items[i : i + 2]:
            row.append(_button(_mark(label, current == key), f"pos:{key}:{category}"))
        rows.append(row)
    rows.append(back_row(f"sub:{category}"))
    return InlineKeyboardMarkup(rows)

def animation_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    current = settings.get("animation")
    rows = []
    for key, label in ANIMATIONS.items():
        rows.append([_button(_mark(label, current == key), f"anim:{key}:{category}")])
    rows.append(back_row(f"sub:{category}"))
    return InlineKeyboardMarkup(rows)

def font_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    current = settings.get("font")
    rows = []
    items = list(FONTS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, (label, _file) in items[i : i + 2]:
            row.append(_button(_mark(label, current == key), f"font:{key}:{category}"))
        rows.append(row)
    rows.append(back_row(f"sub:{category}"))
    return InlineKeyboardMarkup(rows)

def color_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    current = (settings.get("color") or "").upper()
    rows = []
    items = list(COLORS.items())
    for i in range(0, len(items), 2):
        row = []
        for key, hexval in items[i : i + 2]:
            selected = current == hexval.upper()
            row.append(_button(_mark(f"● {key.title()}", selected), f"color:{key}:{category}"))
        rows.append(row)
    rows.append([_button("🎨 Custom HEX", f"color:custom:{category}")])
    rows.append(back_row(f"sub:{category}"))
    return InlineKeyboardMarkup(rows)

def size_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    current = settings.get("size")
    rows = [[]]
    for preset in SIZE_PRESETS:
        rows[0].append(_button(_mark(f"{preset}%", current == preset), f"size:{preset}:{category}"))
    rows.append(back_row(f"sub:{category}"))
    return InlineKeyboardMarkup(rows)

def opacity_keyboard(settings: dict[str, Any], category: str = "video") -> InlineKeyboardMarkup:
    current = settings.get("opacity")
    rows = [[]]
    for preset in OPACITY_PRESETS:
        rows[0].append(_button(_mark(f"{preset}%", current == preset), f"opacity:{preset}:{category}"))
    rows.append(back_row(f"sub:{category}"))
    return InlineKeyboardMarkup(rows)

def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="m")]])
