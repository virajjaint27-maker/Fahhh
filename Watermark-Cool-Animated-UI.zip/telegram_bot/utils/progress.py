"""High-energy animated progress bar and dynamic HUD visualizers."""
from __future__ import annotations

import time
from typing import Optional

try:
    from pyrogram.errors import FloodWait, MessageNotModified
except ImportError:
    class FloodWait(Exception):
        value = 0
    class MessageNotModified(Exception):
        pass

from telegram_bot.utils.text_style import monospace_text

BAR_LENGTH = 12

# Cool multi-stage animation frames
SPINNER_FRAMES = ["⚡", "✨", "🔥", "💫", "🚀", "💥", "🔮", "🛸"]
CYBER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

def human_size(num: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024.0:
            return f"{num:3.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} PB"

def render_bar(percent: float, length: int = BAR_LENGTH) -> str:
    percent = max(0.0, min(100.0, percent))
    filled = int(length * percent / 100)
    # Cool neon gradient blocks
    return "▰" * filled + "▱" * (length - filled)

class ProgressTracker:
    def __init__(self, message, prefix: str, min_interval: float = 2.0):
        self.message = message
        self.prefix = prefix
        self.min_interval = min_interval
        self.start_time = time.monotonic()
        self._last_edit = 0.0
        self._last_percent = -1.0
        self._frame = 0

    async def _safe_edit(self, text: str) -> None:
        try:
            await self.message.edit_text(text, parse_mode="HTML")
        except MessageNotModified:
            pass
        except FloodWait as exc:
            time.sleep(min(exc.value, 8))
        except Exception:
            pass

    async def update(self, current: int, total: int) -> None:
        now = time.monotonic()
        percent = (current / total * 100) if total else 0.0
        significant_change = abs(percent - self._last_percent) >= 2 or percent >= 100
        if now - self._last_edit < self.min_interval and not significant_change:
            return
        self._last_edit = now
        self._last_percent = percent
        elapsed = max(now - self.start_time, 0.001)
        speed = current / elapsed
        eta = (total - current) / speed if speed > 0 else 0
        self._frame = (self._frame + 1) % len(SPINNER_FRAMES)
        spinner = SPINNER_FRAMES[self._frame]
        cyber = CYBER_FRAMES[self._frame % len(CYBER_FRAMES)]

        text = (
            f"<blockquote><b>{spinner} {self.prefix} {cyber}</b>\n\n"
            f"<code>[{render_bar(percent)}] {percent:5.1f}%</code>\n\n"
            f"⚡ <b>Transferred:</b> <code>{human_size(current)} / {human_size(total)}</code>\n"
            f"🚀 <b>Velocity:</b> <code>{human_size(speed)}/s</code>\n"
            f"⏳ <b>Time Remaining:</b> <code>~{int(eta)}s</code></blockquote>"
        )
        await self._safe_edit(text)

    async def finish(self, text: str) -> None:
        await self._safe_edit(text)
