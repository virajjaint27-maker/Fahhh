"""Rich message formatting with cool visual aesthetics, fire badges, and expandable article cards."""
from __future__ import annotations

from typing import Any
from telegram_bot.constants import ANIMATIONS, FONTS, POSITIONS

_SERIF_BOLD_OFFSET_UPPER = 0x1D400 - ord('A')  # 𝐀
_SERIF_BOLD_OFFSET_LOWER = 0x1D41A - ord('a')  # 𝐚

def serif_bold(text: str) -> str:
    out = []
    for char in text:
        code = ord(char)
        if ord('A') <= code <= ord('Z'):
            out.append(chr(code + _SERIF_BOLD_OFFSET_UPPER))
        elif ord('a') <= code <= ord('z'):
            out.append(chr(code + _SERIF_BOLD_OFFSET_LOWER))
        else:
            out.append(char)
    return "".join(out)

def format_article(header: str, body: str, *, expandable: bool = True) -> str:
    tag = '<blockquote expandable>' if expandable else '<blockquote>'
    return f"{tag}<b>{header}</b>\n\n{body}</blockquote>"

def welcome_rich_message() -> str:
    title = f"⚡ <b>{serif_bold('OMEGA STUDIO ULTIMATE')}</b> 🔥 😎"
    body = (
        "🚀 <i>The most powerful automated visual stamping & forwarding studio on Telegram.</i>\n\n"
        "✨ <b>PRO FEATURES UNLOCKED:</b>\n"
        "• 📹 <b>Cinematic 4K/60fps Video Engine</b> (Zero Quality Loss)\n"
        "• 🖼️ <b>Ultra-HD Raster Stamping</b> (HDR, WebP, PNG)\n"
        "• 📄 <b>PDF Document Watermarking</b> (Clean Vector Overlay)\n"
        "• 🎬 <b>Dynamic Motion Effects</b> (DVD Bounce 📀, Fade Waves 🌊)\n"
        "• 🔁 <b>Turbo Channel Message Forwarder</b> (Instant Bulk Sync ⚡)\n\n"
        "🔥 <b>Limitless Capacity:</b> Stream transfers up to <b>2000 MiB</b>!\n\n"
        "👇 <i>Tap any option below to start crafting your visuals:</i>"
    )
    article = format_article("👑 Cybernetic Automation Core", body, expandable=True)
    return f"{title}\n\n{article}"

def settings_summary(settings: dict[str, Any]) -> str:
    title = f"🎨 <b>{serif_bold('Watermark Settings Hub')}</b> ⚡ 💎"
    body = (
        "🎛️ <b>Multi-Engine Media Matrix</b>\n"
        "Configure custom overlays, animations, and render profiles.\n"
        "Each engine operates independently with persistent state memory.\n\n"
        "• 📹 <b>Video Engine:</b> 60fps re-encoding, motion physics, audio pass-through.\n"
        "• 🖼️ <b>Image Engine:</b> High-res alpha blending, custom opacity.\n"
        "• 📄 <b>Document Engine:</b> Vector typography & stamps.\n"
        "• 🔁 <b>Channel Forwarder:</b> Automated channel-to-channel cloner.\n"
        "• 🌐 <b>Global Defaults:</b> Sync master presets across all formats."
    )
    article = format_article("⚙️ Active Hardware Profiles", body, expandable=True)
    return f"{title}\n\n{article}"

def media_category_article(category: str, settings: dict[str, Any]) -> str:
    cat_names = {
        "video": ("📹", "Video Motion Engine", "Hardware-accelerated libx264 transcoding with dynamic motion effects."),
        "image": ("🖼️", "Ultra-HD Image Engine", "Vector rasterizer with custom PNG alpha transparency and scaling."),
        "pdf":   ("📄", "Document PDF Engine",   "High-precision document header/footer stamping."),
        "global":("🌐", "Global Master Preset",  "Master fallback rules applied across all incoming tasks."),
    }
    icon, name, desc = cat_names.get(category, ("⚙️", "Media Pipeline", "Media configuration."))
    title = f"{icon} <b>{serif_bold(name)}</b> 🔥"
    
    mode = settings.get("mode", "text")
    txt = settings.get("text") or "@YourBrand"
    pos = POSITIONS.get(settings.get("position", "bottom_right"), "Bottom Right")
    anim = ANIMATIONS.get(settings.get("animation", "none"), "None")
    
    body = (
        f"💫 {desc}\n\n"
        f"• 🏷️ <b>Overlay Mode:</b> <code>{'🅰️ Text' if mode == 'text' else '🖼️ Logo'}</code>\n"
        f"• ✏️ <b>Watermark Text:</b> <code>{txt}</code>\n"
        f"• 📍 <b>Anchor Position:</b> <code>{pos}</code>\n"
        f"• 📏 <b>Scale Factor:</b> <code>{settings.get('size', 5)}%</code>\n"
        f"• 💧 <b>Transparency:</b> <code>{settings.get('opacity', 70)}%</code>\n"
        f"• 🎬 <b>Animation Physics:</b> <code>{anim}</code>\n\n"
        "👇 <i>Tap any parameter below to modify in real-time:</i>"
    )
    article = format_article("🔧 Live Tuning Dashboard", body, expandable=True)
    return f"{title}\n\n{article}"

def vip_feature_card() -> str:
    title = f"👑 <b>{serif_bold('VIP & ULTRA PLAN — STUDIO ACCESS')}</b> 🔥 ⚡"
    body = (
        "✨ <b>Unlock Dedicated Enterprise Infrastructure:</b>\n\n"
        "• 🚀 <b>Dedicated NVENC GPU Processing</b> (10x render speed)\n"
        "• ⚡ <b>Unlimited Auto-Forwarding Bots</b>\n"
        "• 📀 <b>Exclusive 3D Holographic Animations</b>\n"
        "• 🛡️ <b>Priority Anti-Flood Bypass</b>\n"
        "• 👨‍💻 <b>24/7 VIP Direct Support & Channel Automation</b>"
    )
    article = format_article("💎 Enterprise VIP Tier", body, expandable=True)
    return f"{title}\n\n{article}"

def config_overview_card(settings: dict[str, Any]) -> str:
    title = f"📊 <b>{serif_bold('Master Configuration Matrix')}</b> 😎 ⚡"
    txt = (settings.get("text") or "@YourBrand")[:16]
    font_name = FONTS.get(settings.get("font", "poppins_bold"), ("Poppins", ""))[0][:7]
    
    lines = [
        f"{'Engine':<8} {'Status':<6} {'Brand Text':<17} {'Font':<7}",
        "═" * 40,
        f"{'📹 Video':<8} {'🟢 ON':<6} {txt:<17} {font_name:<7}",
        f"{'🖼️ Image':<8} {'🟢 ON':<6} {txt:<17} {font_name:<7}",
        f"{'📄 PDF':<8}   {'🟢 ON':<6} {txt:<17} {font_name:<7}",
    ]
    table = "<pre>\n" + "\n".join(lines) + "\n</pre>"
    notice = (
        "💡 <i>All media engines run in isolated sandboxes.</i>\n"
        "Tap any engine below to fine-tune your parameters."
    )
    article = format_article("📌 Pipeline Matrix Status", notice, expandable=True)
    return f"{title}\n\n{table}\n\n{article}"

def help_rich_message() -> str:
    title = f"📖 <b>{serif_bold('Omega Studio Command Center')}</b> 🎮 🚀"
    body = (
        "• 🚀 <b>/start</b> — Launch Cyber Studio & Master Dashboard\n"
        "• 🎨 <b>/settings</b> — Open Watermark Multi-Engine Matrix\n"
        "• 📊 <b>/mysettings</b> — View Real-Time Status Table\n"
        "• 🔁 <b>/forward</b> — Turbo Channel Forwarding Engine\n"
        "• 👑 <b>/vip</b> — Instant VIP Upgrades & Cloud Batching\n"
        "• 🛑 <b>/cancel</b> — Reset Active Input State\n\n"
        "🔥 <i>Drop any video, photo, GIF, or document right here for instant stamping!</i>"
    )
    article = format_article("⚡ Command Directives", body, expandable=True)
    return f"{title}\n\n{article}"
