from __future__ import annotations

import logging
from pyrogram import filters
from pyrogram.enums import ParseMode
from pyrogram.types import CallbackQuery, Message

from telegram_bot.bot import app
from telegram_bot.config import ASSETS_DIR
from telegram_bot.utils.membership import (
    check_channel_membership,
    join_keyboard,
    join_prompt,
)
from telegram_bot.utils.stickers import next_random_item, send_random_sticker
from telegram_bot.utils.formatting import help_rich_message, welcome_rich_message
from telegram_bot.utils.keyboards import welcome_keyboard

log = logging.getLogger(__name__)

WELCOME_IMAGES = (
    str(ASSETS_DIR / "watermark-welcome-1.png"),
    str(ASSETS_DIR / "watermark-welcome-2.png"),
)

@app.on_message(filters.command("start") & filters.private)
async def start_cmd(client, message: Message):
    user_id = message.from_user.id
    log.info("Received /start from Telegram user %s", user_id)

    await send_random_sticker(
        client,
        message.chat.id,
        "start",
        user_id=user_id,
        reply_to_message_id=message.id,
    )

    member_status = await check_channel_membership(client, user_id)
    caption = welcome_rich_message() if member_status is True else join_prompt(member_status)
    keyboard = welcome_keyboard() if member_status is True else join_keyboard()
    image = next_random_item(WELCOME_IMAGES, category="welcome-image", user_id=user_id)

    try:
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            caption=caption,
            reply_markup=keyboard,
            parse_mode=ParseMode.HTML,
            reply_to_message_id=message.id,
        )
    except Exception:
        log.exception("Could not send the welcome image, sending text message instead")
        await message.reply_text(caption, reply_markup=keyboard, parse_mode=ParseMode.HTML)

@app.on_message(filters.command("help") & filters.private)
async def help_cmd(client, message: Message):
    await message.reply_text(help_rich_message(), reply_markup=welcome_keyboard(), parse_mode=ParseMode.HTML)

@app.on_callback_query(filters.regex(r"^join:check$"))
async def join_check_callback(client, cq: CallbackQuery):
    member_status = await check_channel_membership(client, cq.from_user.id)
    if member_status is True:
        await cq.answer("✅ Channel membership verified!", show_alert=True)
        try:
            await cq.message.edit_text(welcome_rich_message(), reply_markup=welcome_keyboard(), parse_mode=ParseMode.HTML)
        except Exception:
            pass
    else:
        await cq.answer("⚠️ You have not joined the channel yet. Please join and try again.", show_alert=True)
