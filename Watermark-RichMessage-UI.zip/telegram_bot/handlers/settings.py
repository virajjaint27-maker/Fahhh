from __future__ import annotations

import re
from pyrogram import filters
from pyrogram.enums import ParseMode
from pyrogram.types import CallbackQuery, Message

from telegram_bot.bot import PENDING_INPUT, app
from telegram_bot.config import CHANNEL_URL
from telegram_bot.constants import COLORS
from telegram_bot.db import get_settings, reset_settings, update_settings
from telegram_bot.utils.membership import require_channel_membership
from telegram_bot.utils.formatting import (
    config_overview_card,
    help_rich_message,
    media_category_article,
    settings_summary,
    vip_feature_card,
    welcome_rich_message,
)
from telegram_bot.utils.keyboards import (
    animation_keyboard,
    cancel_keyboard,
    color_keyboard,
    font_keyboard,
    main_menu_keyboard,
    media_subconfig_keyboard,
    opacity_keyboard,
    overview_keyboard,
    position_keyboard,
    size_keyboard,
    vip_keyboard,
    welcome_keyboard,
)

CALLBACK_PATTERN = re.compile(
    r"^(m|close|reset|help|nav:(start|vip|overview)|sub:(video|image|pdf|global)|"
    r"mode:(text|image)(:[a-z]+)?|pos:(menu|[a-z_]+)(:[a-z]+)?|anim:(menu|[a-z_]+)(:[a-z]+)?|"
    r"font:(menu|[a-z_]+)(:[a-z]+)?|color:(menu|custom|[a-z]+)(:[a-z]+)?|size:(menu|custom|\d+)(:[a-z]+)?|"
    r"opacity:(menu|custom|\d+)(:[a-z]+)?|text:ask(:[a-z]+)?|logo:ask(:[a-z]+)?)$"
)

async def _edit_callback_message(message: Message, text: str, reply_markup=None) -> None:
    try:
        if message.photo or message.video or message.animation or message.document:
            await message.edit_caption(text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
        else:
            await message.edit_text(text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    except Exception:
        pass

async def _answer_callback(cq: CallbackQuery, text: str | None = None, **kwargs) -> None:
    if text is None:
        await cq.answer(**kwargs)
    else:
        await cq.answer(text, **kwargs)

@app.on_message(filters.command("settings") & filters.private)
async def settings_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    settings = await get_settings(message.from_user.id)
    await message.reply_text(
        settings_summary(settings),
        reply_markup=main_menu_keyboard(settings),
        parse_mode=ParseMode.HTML
    )

@app.on_message(filters.command(["mysettings", "overview"]) & filters.private)
async def mysettings_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    settings = await get_settings(message.from_user.id)
    await message.reply_text(
        config_overview_card(settings),
        reply_markup=overview_keyboard(),
        parse_mode=ParseMode.HTML
    )

@app.on_message(filters.command(["batch", "vip"]) & filters.private)
async def batch_cmd(client, message: Message):
    if not await require_channel_membership(client, message):
        return
    admin_link = CHANNEL_URL or "https://t.me/telegram"
    await message.reply_text(
        vip_feature_card(),
        reply_markup=vip_keyboard(admin_link),
        parse_mode=ParseMode.HTML
    )

@app.on_callback_query(filters.regex(CALLBACK_PATTERN))
async def settings_callback(client, cq: CallbackQuery):
    user_id = cq.from_user.id
    data = cq.data

    if cq.message is not None and not await require_channel_membership(client, cq.message, user_id=user_id):
        await _answer_callback(cq, "Please join the channel before using the bot.", show_alert=True)
        return

    if data == "nav:start":
        await _edit_callback_message(cq.message, welcome_rich_message(), reply_markup=welcome_keyboard())
        await _answer_callback(cq)
        return

    if data == "nav:overview":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, config_overview_card(settings), reply_markup=overview_keyboard())
        await _answer_callback(cq)
        return

    if data == "nav:vip":
        admin_link = CHANNEL_URL or "https://t.me/telegram"
        await _edit_callback_message(cq.message, vip_feature_card(), reply_markup=vip_keyboard(admin_link))
        await _answer_callback(cq)
        return

    if data == "m":
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, settings_summary(settings), reply_markup=main_menu_keyboard(settings))
        await _answer_callback(cq)
        return

    if data.startswith("sub:"):
        cat = data.split(":", 1)[1]
        settings = await get_settings(user_id)
        await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=media_subconfig_keyboard(settings, cat))
        await _answer_callback(cq)
        return

    if data == "help":
        await _answer_callback(cq)
        await _edit_callback_message(cq.message, help_rich_message(), reply_markup=welcome_keyboard())
        return

    # Subcategory configurations (pos, font, anim, color, size, opacity)
    parts = data.split(":")
    action = parts[0]
    cat = parts[2] if len(parts) >= 3 else "video"

    if action == "pos":
        val = parts[1]
        settings = await get_settings(user_id)
        if val == "menu":
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=position_keyboard(settings, cat))
        else:
            settings = await update_settings(user_id, position=val)
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=position_keyboard(settings, cat))
            await _answer_callback(cq, "Position updated")
        return

    if action == "anim":
        val = parts[1]
        settings = await get_settings(user_id)
        if val == "menu":
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=animation_keyboard(settings, cat))
        else:
            settings = await update_settings(user_id, animation=val)
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=animation_keyboard(settings, cat))
            await _answer_callback(cq, "Animation updated")
        return

    if action == "font":
        val = parts[1]
        settings = await get_settings(user_id)
        if val == "menu":
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=font_keyboard(settings, cat))
        else:
            settings = await update_settings(user_id, font=val)
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=font_keyboard(settings, cat))
            await _answer_callback(cq, "Font updated")
        return

    if action == "color":
        val = parts[1]
        settings = await get_settings(user_id)
        if val == "menu":
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=color_keyboard(settings, cat))
        elif val == "custom":
            PENDING_INPUT[user_id] = "color"
            await cq.message.reply_text("🎨 Send a hex color code (e.g. <code>#FFFFFF</code>):", reply_markup=cancel_keyboard(), parse_mode=ParseMode.HTML)
        else:
            hexval = COLORS.get(val, "#FFFFFF")
            settings = await update_settings(user_id, color=hexval)
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=color_keyboard(settings, cat))
            await _answer_callback(cq, f"Color: {val}")
        return

    if action == "size":
        val = parts[1]
        settings = await get_settings(user_id)
        if val == "menu":
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=size_keyboard(settings, cat))
        else:
            settings = await update_settings(user_id, size=int(val))
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=size_keyboard(settings, cat))
            await _answer_callback(cq, f"Size: {val}%")
        return

    if action == "opacity":
        val = parts[1]
        settings = await get_settings(user_id)
        if val == "menu":
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=opacity_keyboard(settings, cat))
        else:
            settings = await update_settings(user_id, opacity=int(val))
            await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=opacity_keyboard(settings, cat))
            await _answer_callback(cq, f"Opacity: {val}%")
        return

    if action == "mode":
        mode_val = parts[1]
        settings = await update_settings(user_id, mode=mode_val)
        await _edit_callback_message(cq.message, media_category_article(cat, settings), reply_markup=media_subconfig_keyboard(settings, cat))
        await _answer_callback(cq, f"Mode: {mode_val}")
        return

    if action == "text" and parts[1] == "ask":
        PENDING_INPUT[user_id] = "text"
        await cq.message.reply_text("✏️ Send your custom watermark text (up to 40 characters):", reply_markup=cancel_keyboard(), parse_mode=ParseMode.HTML)
        await _answer_callback(cq)
        return

    if action == "logo" and parts[1] == "ask":
        PENDING_INPUT[user_id] = "logo"
        await cq.message.reply_text("🖼️ Send the image to use as your logo watermark:", reply_markup=cancel_keyboard(), parse_mode=ParseMode.HTML)
        await _answer_callback(cq)
        return
