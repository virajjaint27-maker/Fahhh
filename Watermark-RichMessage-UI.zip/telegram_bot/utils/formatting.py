"""Rich message formatting using Telegram native expandable article cards and serif typography."""
from __future__ import annotations

from typing import Any
from telegram_bot.constants import ANIMATIONS, FONTS, POSITIONS

_SERIF_BOLD_OFFSET_UPPER = 0x1D400 - ord('A')  # 𝐀
_SERIF_BOLD_OFFSET_LOWER = 0x1D41A - ord('a')  # 𝐚

def serif_bold(text: str) -> str:
    """Format text into Unicode Mathematical Bold Serif."""
    out = []
    for char in text:
        code = ord(char)
        if ord('A') <= code <= ord('Z'):
            out.append(chr(code + _SERIF_BOLD_OFFSET_UPPER))
        elif ord('a') <= code <= ord('z'):
            out.append(chr(code + _SERIF_BOLD_OFFSET_LOWER))
        else:
            out.append(char)
    return "".join(out)

def format_article(header: str, body: str, *, expandable: bool = True) -> str:
    """Rich article container using Telegram expandable blockquote with left accent border."""
    tag = '<blockquote expandable>' if expandable else '<blockquote>'
    return f"{tag}<b>{header}</b>\n\n{body}</blockquote>"

def welcome_rich_message() -> str:
    """Rich /start intro message formatted with a headline and expandable article card."""
    title = f"🚀 <b>{serif_bold('Welcome to Watermark Omega Studio')}</b>"
    body = (
        "Professional automated watermark engine for all your media assets.\n\n"
        "✨ <b>Supported Pipelines:</b>\n"
        "• 📹 <b>Video Watermarking</b> (H.264, 60fps, 4K supported)\n"
        "• 🖼️ <b>Photo & Image Watermarking</b> (JPEG, PNG, WEBP, HDR)\n"
        "• 📄 <b>PDF Document Watermarking</b> (Vector text & stamp)\n"
        "• 🎬 <b>Cinematic Animations</b> (DVD Bounce, Fade In/Out)\n\n"
        "📁 <b>Capacity:</b> Up to 2000 MiB per file with instant cloud streaming.\n\n"
        "Tap <b>Settings Hub</b> below to customize your brand overlay, or send any media file immediately!"
    )
    article = format_article("⚡ Automated Production Engine", body, expandable=True)
    return f"{title}\n\n{article}"

def settings_summary(settings: dict[str, Any]) -> str:
    """Settings Hub overview with expandable article."""
    title = f"🎨 <b>{serif_bold('Watermark Settings Hub')}</b>"
    body = (
        "Select a media category below to configure watermarks for your files.\n"
        "Each media category maintains independent persistent settings.\n\n"
        "• <b>Video Watermark:</b> Position, font, color, opacity, animation.\n"
        "• <b>Image Watermark:</b> High-resolution overlay & text branding.\n"
        "• <b>PDF Watermark:</b> Stamp placement & page headers/footers.\n"
        "• <b>Global Defaults:</b> Sync preferences across all categories."
    )
    article = format_article("⚙️ Pipeline Profiles", body, expandable=True)
    return f"{title}\n\n{article}"

def media_category_article(category: str, settings: dict[str, Any]) -> str:
    """Rich article for a specific media subcategory."""
    cat_names = {
        "video": ("📹", "Video Watermark Pipeline", "Configures H.264 video re-encoding, bouncing DVD overlays, and audio-pass watermark stamping."),
        "image": ("🖼️", "Image Watermark Pipeline", "Configures high-speed raster stamping, custom PNG alpha transparency, and resolution scaling."),
        "pdf":   ("📄", "PDF Watermark Pipeline",   "Configures document stamps, vector text overlay, page ranges, and background opacities."),
        "global":("🌐", "Global Default Settings",   "Global fallback preferences applied when individual media overrides are not explicitly set."),
    }
    icon, name, desc = cat_names.get(category, ("⚙️", "Media Pipeline", "Media configuration."))
    title = f"{icon} <b>{serif_bold(name)}</b>"
    
    mode = settings.get("mode", "text")
    txt = settings.get("text") or "@YourBrand"
    pos = POSITIONS.get(settings.get("position", "bottom_right"), "Bottom Right")
    anim = ANIMATIONS.get(settings.get("animation", "none"), "None")
    
    body = (
        f"{desc}\n\n"
        f"• <b>Mode:</b> <code>{'Text' if mode == 'text' else 'Logo Image'}</code>\n"
        f"• <b>Text:</b> <code>{txt}</code>\n"
        f"• <b>Position:</b> <code>{pos}</code>\n"
        f"• <b>Size:</b> <code>{settings.get('size', 5)}%</code>\n"
        f"• <b>Opacity:</b> <code>{settings.get('opacity', 70)}%</code>\n"
        f"• <b>Animation:</b> <code>{anim}</code>\n\n"
        "Tap any parameter below to adjust your active profile."
    )
    article = format_article("🔧 Active Pipeline Parameters", body, expandable=True)
    return f"{title}\n\n{article}"

def vip_feature_card() -> str:
    """VIP / Channel Batch Watermarking view."""
    title = f"👑 <b>{serif_bold('VIP Exclusive Feature — Channel Batch')}</b>"
    body = (
        "⚡ <b>Channel Batch Watermarking</b> is an automated tool "
        "reserved exclusively for VIP & Ultra Plan users.\n\n"
        "• Automatic channel monitor & forward-stamping.\n"
        "• Zero queue wait time & dedicated GPU transcoding.\n"
        "• Unlimited file size and batch bulk imports."
    )
    article = format_article("⚡ Accelerated Enterprise Access", body, expandable=True)
    return f"{title}\n\n{article}"

def config_overview_card(settings: dict[str, Any]) -> str:
    """Tabular configuration overview matching the reference /mysettings screen."""
    title = f"📊 <b>{serif_bold('My Watermark Configuration')}</b>"
    txt = (settings.get("text") or "@YourBrand")[:16]
    font_name = FONTS.get(settings.get("font", "poppins_bold"), ("Poppins", ""))[0][:7]
    
    lines = [
        f"{'Media':<7} {'Status':<6} {'Text':<17} {'Font':<7}",
        "─" * 40,
        f"{'📹 Video':<7} {'🟢 ON':<6} {txt:<17} {font_name:<7}",
        f"{'🖼️ Image':<7} {'🟢 ON':<6} {txt:<17} {font_name:<7}",
        f"{'📄 PDF':<7}   {'🟢 ON':<6} {txt:<17} {font_name:<7}",
    ]
    table = "<pre>\n" + "\n".join(lines) + "\n</pre>"
    notice = (
        "Video, Image, and PDF maintain isolated persistent settings.\n"
        "To modify any pipeline configuration, tap the category buttons below."
    )
    article = format_article("📌 Configuration Notice", notice, expandable=True)
    return f"{title}\n\n{table}\n\n{article}"

def help_rich_message() -> str:
    """Help documentation article."""
    title = f"📖 <b>{serif_bold('Watermark Omega Help & Commands')}</b>"
    body = (
        "• <b>/start</b> — Launch the studio & main dashboard\n"
        "• <b>/settings</b> — Open Watermark Settings Hub\n"
        "• <b>/mysettings</b> — View tabular configuration overview\n"
        "• <b>/batch</b> or <b>/vip</b> — Access channel batch automation\n"
        "• <b>/cancel</b> — Cancel any active prompt or text input\n\n"
        "💡 <b>Tip:</b> Just send any media directly to stamp your watermark instantly!"
    )
    article = format_article("ℹ️ Command Index", body, expandable=True)
    return f"{title}\n\n{article}"
